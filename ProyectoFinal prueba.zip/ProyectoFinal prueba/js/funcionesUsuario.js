var dt;

function usuario(){

  $("#login-form").on('submit',function(e){    
    e.preventDefault();
    var datos = $(this).serialize();
    // console.log(datos)
    $.ajax({
        type:"post",
        url:"php/usuario/controladorUsuario.php",
        data: datos,
        dataType:"json"
      }).done(function( resultado ) {
        // console.log(resultado);
        if(resultado.respuesta == "existe"){
        // if(resultado.respuesta == "empleado"){
            location.href ="tablas.php";
        }
        // else if (resultado.respuesta == "usuario"){
        //     location.href ="index.php";
        // }
        else{
            swal({
                position: 'center',
                type: 'error',
                title: 'Usuario y/o Password incorrecto',
                showConfirmButton: false,
                timer: 1500
            }),
            function() {
                $("#usuario").focus().select();
            };                
          }
    });
})


    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fusuario").serialize();
         $.ajax({
            type:"get",
            url:"./php/usuario/controladorUsuarios.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Usuario");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#usuario").removeClass("hide");
                $("#usuario").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el usuario con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/usuario/controladorUsuarios.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El usuario con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Usuario");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#usuario").removeClass("hide");
        $("#usuario").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Usuario");
        var rol;
        $("#nuevo-editar" ).load("./php/usuario/nuevoUsuario.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#usuario").removeClass("show");
        $("#usuario").addClass("hide");
        $.ajax({
            type:"get",
            url:"./php/direccion/controladorDireccion.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#address_id option").remove()       
             $("#address_id").append("<option selecte value=''>Seleccione una Direccion</option>")
             $.each(resultado.data, function (index, value) { 
               $("#address_id").append("<option value='" + value.address_id + "'>" + value.address + "</option>")
             });
          });  
          $.ajax({
            type:"get",
            url:"./php/rol/controladorRol.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#rol_id option").remove()       
             $("#rol_id").append("<option selecte value=''>Seleccione un rol</option>")
             $.each(resultado.data, function (index, value) { 
               $("#rol_id").append("<option value='" + value.rol_id + "'>" + value.rol_name + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fusuario").serialize();
       $.ajax({
            type:"get",
            url:"./php/usuario/controladorUsuarios.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado usuario");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#usuario").removeClass("hide");
                $("#usuario").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar usuario");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var direccion;
       var rol;
        $("#nuevo-editar").load("./php/usuario/editarUsuario.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#usuario").removeClass("show");
        $("#usuario").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/usuario/controladorUsuarios.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( usuario ) {        
                if(usuario.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El usuario no existe!!!!!'                         
                    })
                } else {
                    $("#staff_id").val(usuario.codigo);                   
                    $("#first_name").val(usuario.nombre);
                    $("#last_name").val(usuario.apellido);                   
                    direccion = usuario.direccion;                  
                    $("#email").val(usuario.email);    
                    $("#rol_id").val(usuario.rol);
                    $("#username").val(usuario.usuario);
                    $("#password").val(usuario.contrasena);                   
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/direccion/controladorDireccion.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#address_id option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(direccion === value.address_id){
                 $("#address_id").append("<option selected value='" + value.address_id + "'>" + value.address + "</option>")
               }else {
                 $("#address_id").append("<option value='" + value.address_id + "'>" + value.address + "</option>")
               }
             });
            });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Usuarios");
  dt = $("#tabla").DataTable({
        "ajax": "php/usuario/controladorUsuarios.php?accion=listar",
        "columns": [
            { "data": "staff_id"} ,
            { "data": "empleado" },
            { "data": "address" },
            { "data": "email" },
            { "data": "rol_name" },
            { "data": "username" },
            
            { "data": "staff_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "staff_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  usuario();
});