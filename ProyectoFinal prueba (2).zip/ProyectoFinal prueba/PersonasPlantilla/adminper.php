<?php
  include_once ("./Funciones/sessiones.php");
  include_once ('./templates/header.php');

  include_once ('./templates/barra.php');

   include_once ('./templates/navegacion.php');
  
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php
  include_once ('./templates/footer.php')
?>


