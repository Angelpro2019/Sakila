<?php
 
require_once 'tienda_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $tienda = new Tienda();
        $resultado = $tienda->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $tienda = new Tienda();
        $resultado = $tienda->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $tienda = new Tienda();
        $resultado = $tienda->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $tienda = new Tienda();
        $tienda->consultar($datos['codigo']);

        if($tienda->getStore_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $tienda->getStore_id(),
                'manager' => $tienda->getManager_staff_id(),
                'direccion' =>$tienda->getAddress_id(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $tienda = new Tienda();
        $listado = $tienda->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
