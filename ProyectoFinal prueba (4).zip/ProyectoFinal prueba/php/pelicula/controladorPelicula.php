<?php
 
require_once 'pelicula_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $pelicula = new Pelicula();
        $resultado = $pelicula->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $pelicula = new Pelicula();
        $resultado = $pelicula->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $pelicula = new Pelicula();
        $resultado = $pelicula->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $pelicula = new Pelicula();
        $pelicula->consultar($datos['codigo']);

        if($pelicula->getFilm_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $pelicula->getFilm_id(),
                'titulo' => $pelicula->getTitle(),
                'descripcion' =>$pelicula->getDescription(),
                'lanzamiento' => $pelicula->getRelease_year(),
                'idioma' =>$pelicula->getLanguage_id(),
                'duracion' =>$pelicula->getRental_duration(),
                'valor' =>$pelicula->getRental_rate(),
                'longitud' =>$pelicula->getLength(),
                'reemplazo' => $pelicula->getReplacement_cost(),
                'clasificacion' =>$pelicula->getRating(),
                'caracteristicas' => $pelicula->getSpecial_features(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $pelicula = new Pelicula();
        $listado = $pelicula->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
