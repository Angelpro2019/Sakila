  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
    reserved.
  </footer>

  </div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<!-- Bootstrap 3.3.7 -->
<script src="./Recursos/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="./Recursos/js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="./Recursos/js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="./Recursos/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="./Recursos/js/demo.js"></script>
<script src="./Recursos/js/funcionesJquery.js"></script>

<script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.2/sweetalert2.all.js"></script>

<script>
  $(document).ready(Inicio);
</script>
</body>
</html>
