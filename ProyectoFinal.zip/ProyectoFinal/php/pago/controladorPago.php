<?php
 
require_once 'pago_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $pago = new Pago();
        $resultado = $pago->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $pago = new Pago();
        $resultado = $pago->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $pago = new Pago();
        $resultado = $pago->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $pago = new Pago();
        $pago->consultar($datos['codigo']);

        if($pago->getPayment_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $pagos->getPayment_id(),
                'cliente' => $pagos->getCustomer_id(),
                'empleado' => $pagos->getStaff_id(),
                'prestamo' =>$pagos->getRental_id(),
                'precio' => $pagos->getAmount(),
                'fecha_pago' => $pagos->getPayment_date(),
                'fecha' =>$pagos->getLast_update(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $pago = new Pago();
        $listado = $pago->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
