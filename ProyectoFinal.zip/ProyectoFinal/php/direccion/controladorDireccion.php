<?php
 
require_once 'direccion_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $direccion = new Direccion();
		$resultado = $direccion->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $direccion = new Direccion();
		$resultado = $direccion->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$direccion = new Direccion();
		$resultado = $direccion->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $direccion = new Direccion();
        $direccion->consultar($datos['codigo']);

        if($direccion->getaddress_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $direccion->getaddress_id(),
                'direccion' => $direccion->getaddress(),
                'distrito' =>$direccion->getdistrict(),
                'ciudad' =>$direccion->getcity_id(),
                'postal' =>$direccion->getpostal_code(),
                'telefono' =>$direccion->getphone(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $direccion = new Direccion();
        $listado = $direccion->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
