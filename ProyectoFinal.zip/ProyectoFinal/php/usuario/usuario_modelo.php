<?php
	require_once('../modeloAbstractoDB.php');
	class Usuario extends ModeloAbstractoDB {
		public $staff_id; 	
        public $first_name;
        public $last_name;
        public $address_id;
        public $email;
        public $rol_id;
        public $username;
        public $password;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getStaff_id(){
			return $this->staff_id;
		}

		public function getFirst_name(){
			return $this->first_name;
        }
        
        public function getLast_name(){
			return $this->last_name;
        }
        
        public function getAddress_id(){
			return $this->address_id;
        }
        
    
        
        public function getEmail(){
			return $this->email;
		}
        
        public function getStore_id(){
			return $this->store_id;
        }
        
        public function getUsername(){
			return $this->username;
		}
        
        public function getPassword(){
			return $this->password;
		}
		public function getRol_id(){
			return $this->rol_id;
		}
		
          

		public function consultar($staff_id='') {
			if($staff_id != ''):
				$this->query = "
				SELECT staff_id,first_name,last_name,address_id, email, rol_id, username, password 
				FROM staff
				WHERE active!=0 and username= '$username'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT staff_id,CONCAT(s.first_name, ' ', s.last_name) as empleado,address,email,rol_name, username 
            FROM staff as s
            INNER JOIN address as a ON (s.address_id = a.address_id)
            INNER JOIN rol as r ON (s.rol_id = r.rol_id)
            WHERE s.active != 0 
            ORDER BY staff_id
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('staff_id', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO staff
				(first_name,last_name,address_id,email,rol_id,username,password)
				VALUES
				('$first_name','$last_name','$address_id','$email','$rol_id','$username','$password')
				
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE staff
            SET first_name='$first_name',
			last_name='$last_name',
			address_id='$address_id',
			email='$email',
			rol_id='$rol_id',
            username='$username',
            password='$password'
			WHERE staff_id = '$staff_id'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($staff_id='') {
			$this->query = "
			DELETE FROM staff
			WHERE staff_id = '$staff_id'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>