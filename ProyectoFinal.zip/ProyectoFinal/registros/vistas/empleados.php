<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Empleados"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE EMPLEADOS', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'staff_id', 0);
$pdf->Cell(20, 8, 'first_name', 0);
$pdf->Cell(20, 8, 'last_name', 0);
$pdf->Cell(30, 8, 'address', 0);
$pdf->Cell(45, 8, 'email', 0);
$pdf->Cell(20, 8, 'store_id', 0);
$pdf->Cell(40, 8, 'rol_name', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT staff_id,first_name,last_name,address,email,store_id,rol_name
FROM staff as s
INNER JOIN address as a ON (s.address_id = a.address_id)
INNER JOIN rol as r ON (s.rol_id = r.rol_id)
WHERE s.active != 0 and s.rol_id<3
ORDER BY staff_id
");
$item = 0;
while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['staff_id'], 0);
	$pdf->Cell(20, 8,$productos2['first_name'], 0);
	$pdf->Cell(20, 8,$productos2['last_name'], 0);
	$pdf->Cell(30, 8, $productos2['address'], 0);
	$pdf->Cell(45, 8, $productos2['email'], 0);
	$pdf->Cell(20, 8,$productos2['store_id'], 0);
	$pdf->Cell(40, 8, $productos2['rol_name'], 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>