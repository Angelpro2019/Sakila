<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Peliculas', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE Peliculas', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'film_id', 0);
$pdf->Cell(40, 8, 'title', 0);
$pdf->Cell(40, 8, 'category', 0);
$pdf->Cell(25, 8, 'tienda', 0);

$pdf->Cell(25, 8, 'release_year', 0);

$pdf->Cell(25, 8, 'idioma', 0);

$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT  film_id,title,
IFNULL((SELECT GROUP_CONCAT(y.name separator ', ')
	FROM film_category as c
	INNER JOIN category as y ON (c.category_id=y.category_id)
	WHERE c.film_id=f.film_id),'Sin asignar') as categoria,
		IFNULL((SELECT GROUP_CONCAT(DISTINCT store_id separator ', ')
			FROM inventory as i
			WHERE i.film_id=f.film_id),'Sin asignar') as tienda,
			description,release_year,l.name as idioma,rental_rate,length,rating
				FROM film as f
				INNER JOIN language as l
				ON (f.language_id = l.language_id)
				WHERE f.estado != 1
				ORDER BY film_id");
$item = 0;
$totaluni = 0;
$totaldis = 0;
while($productos2 = mysql_fetch_array($productos)){
	$item = $item+1;
	$pdf->Cell(15, 8,$productos2['film_id'], 0);
	$pdf->Cell(40, 8, $productos2['title'], 0);
	$pdf->Cell(40, 8, $productos2['categoria'], 0);
	$pdf->Cell(25, 8, $productos2['tienda'], 0);
	
	$pdf->Cell(25, 8, $productos2['release_year'], 0);
	$pdf->Cell(40, 8, $productos2['idioma'], 0);


	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Cell(31,8,'Total Unitario: S/. '.$totaluni,0);
$pdf->Cell(32,8,'Total Dist: S/. '.$totaldis,0);
$pdf->Output();
?>