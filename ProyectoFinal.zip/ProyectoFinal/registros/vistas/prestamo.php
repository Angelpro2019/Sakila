<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Prestamos"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE PRESTAMO', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'rental_id', 0);
$pdf->Cell(35, 8, 'rental_date', 0);
$pdf->Cell(20, 8, 'inventory_id', 0);
$pdf->Cell(40, 8, 'cliente', 0);
$pdf->Cell(30, 8, 'return_date', 0);
$pdf->Cell(30, 8, 'empleado', 0);
$pdf->Cell(40, 8, 'last_update', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT rental_id, rental_date,i.inventory_id,CONCAT(c.first_name, ' ', c.last_name) as cliente,return_date,CONCAT(s.first_name, ' ', s.last_name) as empleado,r.last_update
FROM rental as r
INNER JOIN customer as c ON (r.customer_id = c.customer_id)
INNER JOIN staff as s ON (r.staff_id = s.staff_id)
INNER JOIN inventory as i ON (r.inventory_id = i.inventory_id)
WHERE r.estado != 1 order by rental_id
				");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['rental_id'], 0);
	$pdf->Cell(35, 8,$productos2['rental_date'], 0);
	$pdf->Cell(20, 8, $productos2['inventory_id'] , 0);
	$pdf->Cell(40, 8, $productos2['cliente'] , 0);
	$pdf->Cell(30, 8,$productos2['return_date'], 0);
	$pdf->Cell(30, 8, $productos2['empleado'] , 0);
	$pdf->Cell(40, 8, $productos2['last_update'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>