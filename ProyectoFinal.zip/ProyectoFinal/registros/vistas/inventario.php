<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Inventario"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE INVENTARIO', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(25, 8, 'inventory_id', 0);
$pdf->Cell(40, 8, 'title', 0);
$pdf->Cell(30, 8, 'store_id', 0);
$pdf->Cell(25, 8, 'last_update', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT i.inventory_id, f.title, i.store_id , i.last_update
FROM inventory as i
INNER JOIN film as f ON (i.film_id = f.film_id)
WHERE i.estado != 1 
ORDER BY i.inventory_id
			");
$item = 0;
while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(25, 8, $productos2['inventory_id'], 0);
	$pdf->Cell(45, 8,$productos2['title'], 0);
	$pdf->Cell(25, 8, $productos2['store_id'], 0);
	$pdf->Cell(25, 8, $productos2['last_update'], 0);
	
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>