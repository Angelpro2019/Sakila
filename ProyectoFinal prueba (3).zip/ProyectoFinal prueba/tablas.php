
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SAKILA CINEMA</title>
  <meta charset="utf-8">
  <link rel="icon" href="Recursos/img/icon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel ="stylesheet" href="css/estilo.css"/>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  
</head>
<style>
.jumbotron {
    background-color: 	#87CEEB;
    color: #fff;
  
}

</style>
<body>
    <div class="container">
        <div class="jumbotron">
            <h1 style=color:black; >Cinema Zakila</h1>   
            <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400" style=color:black></i>
                  Cerrar Seccion
                </a>
              </div>
        </div>
    </div>

    <div class="container">
        <div class="panel-group"><div class="panel panel-info">
            <div class="panel-heading">Tablas de Gestion</div>
            <div class="panel-body">
                
                <div class="form-group" id="opciones">        
                    <div class="col-sm-10">

                        <a class="btn btn-info" href="php/actor/index.php" role="button" style=color:black; >Actores</a>
                        <a class="btn btn-info" href="php/rol/index.php" role="button" style=color:black;>Roles</a>
                        <a class="btn btn-info" href="php/categoria/index.php" role="button" style=color:black;>Categoria</a>
                        <a class="btn btn-info" href="php/ciudad/index.php" role="button" style=color:black;>Ciudades</a>
                        <a class="btn btn-info" href="php/pais/index.php" role="button" style=color:black;>Paises</a>    
                        <a class="btn btn-info" href="php/idioma/index.php" role="button" style=color:black;>Idioma</a>
                        <a class="btn btn-info" href="php/direccion/index.php" role="button" style=color:black;>Direccion</a>
                        <a class="btn btn-info" href="php/empleado/index.php" role="button" style=color:black;>Empleado</a>
                        <a class="btn btn-info" href="php/tienda/index.php" role="button" style=color:black;>Tienda</a>
                        <a class="btn btn-info" href="php/usuario/index.php" role="button" style=color:black;>Usuarios</a>
                        <a class="btn btn-info" href="php/pelicula/index.php" role="button" style=color:black;>Pelicula</a>
                        <a class="btn btn-info" href="php/inventario/index.php" role="button" style=color:black;>Inventario</a>
                        <a class="btn btn-info" href="php/cliente/index.php" role="button" style=color:black;>Cliente</a>
                        <a class="btn btn-info" href="php/prestamo/index.php" role="button" style=color:black;>Prestamo</a>
                        <a class="btn btn-info" href="php/notificaciones/index.php" role="button" style=color:black;>Notificaciones</a>
                        <a class="btn btn-info" href="php/pago/index.php" role="button" style=color:black;>Pagos</a>
                        
                                            
                        
                        
                        
                        
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="panel-group hide" id="contenedor"><div class="panel panel-danger">
            <div class="panel-heading" id="titulo"></div>
            <div class="panel-body">
                
                <div class="form-group" id="contenido">        
                    
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="pagina" value="index" name="editar"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- Librearía para las funcionalidades de la tabla -->
    <script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
    <!-- Librería para las alertas -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.2/sweetalert2.all.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>

    <!-- Funciones de Lógica de negocio -->
    <script src="js/funcionesJquery.js"></script>
    <!-- Funciones de Lógica de neogcio -->
    <script>
        $(document).ready(Inicio);
    </script>
</body>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">¿Desea Finalizar Seccion?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">¿Estas seguro que quieres cerrar sesion?</div>
        <div class="modal-footer">
          <button class="btn btn-info" type="button" data-dismiss="modal">Cancelar</button>
          <a class="btn btn-info" href="index.php?cerrar_session=true">Cerrar sesion</a>
        </div>
      </div>
    </div>
  </div>
</html>